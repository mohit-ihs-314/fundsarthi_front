import { useNavigate, useParams } from "react-router";
import { ArrowLeft, User, MapPin, Phone, Mail, Calendar, Clock, Home } from "lucide-react";
import { Button } from "../../components/ui/button";

export default function BookingDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const booking = {
    id: id,
    clientName: "Amit Verma",
    phone: "+91 98765 43210",
    email: "amit.verma@email.com",
    date: "27 Feb 2026",
    time: "10:00 AM",
    propertyType: "Residential",
    propertyAddress: "Flat 302, Sapphire Heights, Andheri West, Mumbai - 400058",
    concern: "Need complete vastu analysis for new home. Mainly concerned about bedroom placement and main entrance direction.",
    status: "Confirmed",
  };

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="px-6 py-4 bg-card border-b border-border flex items-center">
        <button onClick={() => navigate(-1)} className="text-foreground">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="ml-4">Booking Details</h1>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6">
        {/* Status Badge */}
        <div className="flex items-center justify-between mb-6">
          <div className="px-4 py-2 bg-green-100 text-green-600 rounded-full text-sm">
            {booking.status}
          </div>
          <p className="text-sm text-muted-foreground">Booking ID: #{booking.id}</p>
        </div>

        {/* Client Information */}
        <div className="bg-card rounded-2xl p-5 border border-border mb-4">
          <h3 className="mb-4">Client Information</h3>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <User className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p>{booking.clientName}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Phone className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Phone</p>
                <p className="text-primary">{booking.phone}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="text-primary">{booking.email}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Appointment Details */}
        <div className="bg-card rounded-2xl p-5 border border-border mb-4">
          <h3 className="mb-4">Appointment Details</h3>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Date</p>
                <p>{booking.date}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Clock className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Time</p>
                <p>{booking.time}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Home className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Property Type</p>
                <p>{booking.propertyType}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Property Address */}
        <div className="bg-card rounded-2xl p-5 border border-border mb-4">
          <h3 className="mb-3">Property Address</h3>
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-primary mt-0.5" />
            <p className="text-sm text-muted-foreground">{booking.propertyAddress}</p>
          </div>
        </div>

        {/* Client Concern */}
        <div className="bg-card rounded-2xl p-5 border border-border mb-6">
          <h3 className="mb-3">Client's Concern</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">{booking.concern}</p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90">
            Accept Booking
          </Button>
          <Button variant="outline" className="w-full h-12 rounded-xl">
            Reschedule
          </Button>
          <Button
            variant="outline"
            className="w-full h-12 rounded-xl text-primary border-primary hover:bg-primary/5"
          >
            Mark as Completed
          </Button>
        </div>
      </div>
    </div>
  );
}
