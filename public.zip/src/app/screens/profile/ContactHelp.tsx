export default function ContactHelp() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold">Contact & Help</h1>
      <p className="text-muted-foreground mt-2">
        Coming Soon.
      </p>
    </div>
  );
}