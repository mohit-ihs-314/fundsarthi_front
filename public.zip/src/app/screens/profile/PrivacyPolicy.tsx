export default function PrivacyPolicy() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold">Privacy Policy</h1>
      <p className="text-muted-foreground mt-2">
        Coming Soon.
      </p>
    </div>
  );
}