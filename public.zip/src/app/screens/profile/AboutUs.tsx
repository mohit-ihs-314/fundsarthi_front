export default function AboutUs() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold">About Us</h1>
      <p className="text-muted-foreground mt-2">
        Coming Soon.
      </p>
    </div>
  );
}