import { useNavigate } from "react-router";
import { ArrowLeft, Calendar, ChevronRight } from "lucide-react";
import { useEffect, useState } from "react";

export default function MyConsultations() {

  const navigate = useNavigate();
  const [bookings, setBookings] = useState<any[]>([]);

  useEffect(() => {

    const fetchBookings = async () => {

      const mobile = localStorage.getItem("userMobile");

      if (!mobile) return;

      try {

        const res = await fetch(
          `https://fundsarthi.onrender.com/api/my-consultations?mobile=${mobile}`
        );

        const data = await res.json();

        if (data.status === "success") {
          setBookings(data.data);
        }

      } catch (err) {
        console.error(err);
      }
    };

    fetchBookings();

  }, []);

  const getStatusColor = (status: string) => {

    const colors: Record<string, string> = {
      Pending: "bg-orange-100 text-orange-600",
      Confirmed: "bg-blue-100 text-blue-600",
      Completed: "bg-green-100 text-green-600",
      Cancelled: "bg-red-100 text-red-600",
    };

    return colors[status] || "bg-gray-100 text-gray-600";
  };

  return (
    <div className="h-full flex flex-col bg-background">

      <div className="px-6 py-4 bg-card border-b border-border flex items-center">
        <button onClick={() => navigate(-1)}>
          <ArrowLeft className="w-6 h-6" />
        </button>

        <h1 className="ml-4">
          My Consultations
        </h1>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6">

        <div className="space-y-4">

          {bookings.map((booking) => (

            <button
              key={booking.id}
              onClick={() => navigate(`/track-consultation/${booking.id}`)}
              className="w-full bg-card rounded-2xl p-5 border border-border"
            >

              <div className="flex items-center justify-between mb-4">

                <div className="text-left">
                  <h3>{booking.consultant_name}</h3>

                  <p className="text-sm text-muted-foreground">
                    {booking.consultation_type}
                  </p>
                </div>

                <ChevronRight className="w-5 h-5 text-muted-foreground" />

              </div>

              <div className="flex items-center justify-between text-sm">

                <div>
                  <p className="text-muted-foreground mb-1">
                    Date
                  </p>

                  <p>{booking.date}</p>
                </div>

                <div>
                  <p className="text-muted-foreground mb-1">
                    Time
                  </p>

                  <p>{booking.time}</p>
                </div>

              </div>

              <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">

                <span className="text-sm text-muted-foreground">
                  Status
                </span>

                <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(booking.status)}`}>
                  {booking.status}
                </span>

              </div>

            </button>

          ))}

        </div>

      </div>
    </div>
  );
}