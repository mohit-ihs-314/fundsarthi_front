import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router";
import { BottomNav } from "../../components/BottomNav";
import { GradientButton } from "../../components/ui/gradient-button";
import { Search, SlidersHorizontal, MapPin, Bed, Bath, Square, Home } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "../../components/ui/tabs";

export default function PropertyListing() {
  const navigate = useNavigate();

  // ✅ FIX: default should be BUY
  const [activeTab, setActiveTab] = useState("Residential");

  type PropertyType = {
    id: number;
    title: string;
    location: string;
    price: number;
    beds: string;
    baths: string;
    area: string;
    purpose: string;
    image: string;
    mobile?: string;
    listing_type?: string;

    images?: string[];

    // ✅ ADD THIS
    features?: {
      highlights?: string[];
      facilities?: string[];
      extra?: {
        furnishing?: string;
        construction_status?: string;
        parking?: string;
        project_name?: string;
      };
    };
  };

  const [properties, setProperties] = useState<PropertyType[]>([]);
  const [search, setSearch] = useState("");
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortBy, setSortBy] = useState("");
  const [selectedBuilder, setSelectedBuilder] = useState("");
  const [priceRange, setPriceRange] = useState([2, 15]);

  useEffect(() => {
    fetch("https://fundsarthi.onrender.com/api/properties")
      .then(res => res.json())
      .then(data => setProperties(data))
      .catch(err => {
        console.error("API Error:", err);
      });
  }, []);

  // ✅ NORMALIZE PURPOSE
  const normalizePurpose = (purpose: string) => {
    if (purpose === "sale" || purpose === "sell") return "buy";
    return purpose;
  };

  const normalize = (val: any = "") =>
    val.toString().toLowerCase().replace(/[-_]/g, " ").trim();

  const parsePrice = (price: any) => {
    if (!price) return 0;

    const str = price.toString().toLowerCase();

    if (str.includes("cr")) return parseFloat(str) * 10000000;
    if (str.includes("lakh")) return parseFloat(str) * 100000;

    return parseFloat(str.replace(/[^\d.]/g, "")) || 0;
  };

  // ✅ Dynamic Cities
  const cities = useMemo(() => {
    return [...new Set(
      properties
        .map((p) => {
          const parts = p.location?.split(",");

          // last value = city
          return parts?.[parts.length - 1]?.trim();
        })
        .filter(Boolean)
    )];
  }, [properties]);

  // ✅ Dynamic Locations
  const locations = useMemo(() => {
    return [...new Set(
      properties
        .map((p) => {
          const parts = p.location?.split(",");

          // everything except city
          return parts?.slice(0, -1).join(",").trim();
        })
        .filter(Boolean)
    )];
  }, [properties]);

  // ✅ Dynamic Projects
  const projects = useMemo(() => {
    return [...new Set(
      properties
        .map((p) => p?.features?.extra?.project_name?.trim())
        .filter(Boolean)
    )];
  }, [properties]);

  // ✅ Dynamic Builders
  const builders = useMemo(() => {
    return [...new Set(
      properties
        .map((p: any) =>
          p?.features?.extra?.builder || p?.builder
        )
        .filter(Boolean)
    )];
  }, [properties]);

  const filteredProperties = useMemo(() => {
    let filtered = properties.filter((p) => {

      if (activeTab === "sell") return false;

      const propertyCategory = p?.features?.extra?.category || "Residential";

      if (
        propertyCategory.toLowerCase() !==
        activeTab.toLowerCase()
      ) {
        return false;
      }

      const builderName =
        p?.features?.extra?.builder ||
        (p as any)?.builder ||
        "";

      if (
        selectedBuilder &&
        builderName.toLowerCase() !==
        selectedBuilder.toLowerCase()
      ) {
        return false;
      }

      if (
        search &&
        !p.title.toLowerCase().includes(search.toLowerCase()) &&
        !p.location.toLowerCase().includes(search.toLowerCase())
      ) {
        return false;
      }

      const price = parsePrice(p.price);

      const extra = p?.features?.extra || {};
      const highlights = p?.features?.highlights || [];
      const facilities = p?.features?.facilities || [];

      const amenities = [...highlights, ...facilities].map((a) =>
        normalize(a)
      );

      // ✅ CITY FILTERS
      for (let city of cities) {
        if (
          selectedFilters.includes(city) &&
          !p.location?.toLowerCase().includes(city.toLowerCase())
        ) {
          return false;
        }
      }

      // ✅ LOCATION FILTERS
      for (let loc of locations) {
        if (
          selectedFilters.includes(loc) &&
          !p.location?.toLowerCase().includes(loc.toLowerCase())
        ) {
          return false;
        }
      }

      // ✅ PROJECT FILTERS
      const projectName =
        p?.features?.extra?.project_name || "";

      for (let project of projects) {
        if (
          selectedFilters.includes(project) &&
          !projectName.toLowerCase().includes(project.toLowerCase())
        ) {
          return false;
        }
      }


      // ✅ BUILDER FILTERS
      const builder =
        p?.features?.extra?.builder ||
        (p as any)?.builder ||
        "";

      for (let item of builders) {
        if (
          selectedFilters.includes(item) &&
          !builder.toLowerCase().includes(item.toLowerCase())
        ) {
          return false;
        }
      }

      // ✅ BHK FILTER (FINAL FIX)
      const bhkMap: any = {
        "1 BHK": "1",
        "2 BHK": "2",
        "3 BHK": "3",
        "4 BHK": "4",
      };

      for (let bhk in bhkMap) {
        if (selectedFilters.includes(bhk) && p.beds !== bhkMap[bhk]) {
          return false;
        }
      }

      // ✅ PRICE RANGE FILTER
      const maxPrice = priceRange[1] * 10000000;

      if (price > maxPrice) {
        return false;
      }

      // ✅ Furnishing (FULL FIX)
      const furnishing = normalize(extra.furnishing);

      if (selectedFilters.includes("Furnished") && furnishing !== "furnished") {
        return false;
      }

      if (selectedFilters.includes("Semi Furnished") && !furnishing.includes("semi")) {
        return false;
      }

      if (selectedFilters.includes("Unfurnished") && !furnishing.includes("unfurnished")) {
        return false;
      }

      // ✅ Construction
      const status = normalize(extra.construction_status);

      if (selectedFilters.includes("Ready to Move") && !status.includes("ready")) {
        return false;
      }

      if (selectedFilters.includes("Under Construction") && !status.includes("construction")) {
        return false;
      }

      // ✅ Amenities (DYNAMIC FIX)
      const amenityMap = {
        Parking: ["parking"],
        Gym: ["gym"],
        Lift: ["lift", "elevator"],
        "Swimming Pool": ["swimming", "pool"],
      };

      for (let filter in amenityMap) {
        if (selectedFilters.includes(filter)) {
          const match = amenities.some((a) =>
            amenityMap[filter].some((key) => a.includes(key))
          );

          if (!match) return false;
        }
      }

      console.log({
        title: p.title,
        furnishing,
        status,
        amenities,
        selectedFilters
      });

      return true;
    });


    // ✅ SORTING
    if (sortBy === "lowToHigh") {
      filtered.sort((a, b) => parsePrice(a.price) - parsePrice(b.price));
    }

    if (sortBy === "highToLow") {
      filtered.sort((a, b) => parsePrice(b.price) - parsePrice(a.price));
    }

    return filtered;
  }, [properties, activeTab, search, selectedFilters, sortBy, priceRange]);



  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const fetchUser = async () => {

      const mobile = localStorage.getItem("userMobile");

      if (!mobile) return;

      try {

        const res = await fetch(
          `https://fundsarthi.onrender.com/api/user-profile?mobile=${mobile}`
        );

        const data = await res.json();

        console.log("USER DATA =", data);

        if (data.status === "success") {
          setUser(data.data);
        }

      } catch (err) {
        console.error("Error fetching user:", err);
      }
    };

    fetchUser();
  }, []);

  const [liveLocation, setLiveLocation] =
    useState("Select Location");

  useEffect(() => {

    const updateLocation = () => {

      const currentCity =
        localStorage.getItem("userCity");

      const currentLocality =
        localStorage.getItem("userLocality");

      console.log(
        "LOCATION CHECK =",
        currentLocality,
        currentCity
      );

      if (currentLocality && currentCity) {

        setLiveLocation(
          `${currentLocality}, ${currentCity}`
        );

        return;
      }

      if (currentCity) {

        setLiveLocation(currentCity);

        return;
      }

      if (user?.locality && user?.city) {

        setLiveLocation(
          `${user.locality}, ${user.city}`
        );

        return;
      }

      if (user?.city) {

        setLiveLocation(user.city);

        return;
      }

      setLiveLocation("Select Location");
    };

    // initial load
    updateLocation();

    // listen updates
    window.addEventListener(
      "locationUpdated",
      updateLocation
    );

    return () => {
      window.removeEventListener(
        "locationUpdated",
        updateLocation
      );
    };

  }, [user]);

  const toggleFilter = (chip: string) => {
    setSelectedFilters((prev) =>
      prev.includes(chip)
        ? prev.filter((f) => f !== chip)
        : [...prev, chip]
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f7f8fa] overflow-hidden">

      {/* Header */}
      <div className="px-5 pt-6 pb-5 bg-white sticky top-0 z-30 shadow-sm">

        {/* Top */}
        <div className="flex items-center justify-between mb-5">

          <div>
            <p className="text-xs text-gray-400 mb-1">
              Location
            </p>

            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="w-3 h-3" />
              <span>{liveLocation}</span>
            </div>
            <button
              className="text-primary text-[11px] font-semibold ml-2"
            >
              Use Current Location
            </button>
          </div>

          <button
            onClick={() => navigate("/property/list-your-property")}
            className=" h-12 px-5 rounded-full bg-primary text-white flex items-center gap-2 shadow-lg active:scale-95 transition-all "
          >
            <Home className="w-4 h-4" />
            <span className="text-sm font-semibold">
              Add Property
            </span>
          </button>
        </div>

        {/* Categories */}
        <div className="flex gap-3 mb-5 overflow-x-auto no-scrollbar">

          {[
            "Residential",
            "Commercial",
            "SCO",
            "Plot",
          ].map((item) => (

            <button
              key={item}
              className={`px-5 h-10 rounded-full border text-sm whitespace-nowrap transition-all ${activeTab === item ? "bg-primary text-white border-primary shadow-md" : "bg-white border-gray-200 text-gray-700"}`}
              onClick={() => setActiveTab(item)}
            >
              {item}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="flex gap-3">

          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />

            <input
              type="text"
              placeholder="Search location, property name"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className=" w-full h-12 rounded-full bg-white pl-11 pr-4 text-sm outline-none shadow-sm border border-gray-100 "
            />
          </div>

          <button
            onClick={() => setIsFilterOpen(true)}
            className="w-12 h-12 rounded-full bg-primary flex items-center justify-start pl-3 text-white shadow-lg"
          >
            <SlidersHorizontal className="w-5 h-5" />

            {sortBy && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-yellow-400 rounded-full" />
            )}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-[120px]">



        {/* Recommendations */}
        <div className="px-5 pt-5">

          {/* Heading */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[18px] font-semibold text-gray-900">
              Recommendations
            </h2>


          </div>

          {/* Scrollable Premium Cards */}
          <div className="flex gap-5 overflow-x-auto scroll-smooth snap-x snap-mandatory pb-3 pr-5 no-scrollbar">

            {filteredProperties
              .filter(
                (property) =>
                  property.listing_type === "recommended"
              )
              .slice(0, 8)
              .map((property) => (

                <div
                  key={property.id}
                  onClick={() => navigate(`/property/${property.id}`)}
                  className="
          min-w-[280px]
          max-w-[280px]
          bg-white
          rounded-[28px]
          overflow-hidden
          border
          border-gray-100
          shadow-[0_6px_24px_rgba(0,0,0,0.06)]
          flex-shrink-0
          snap-start
          cursor-pointer
          active:scale-[0.985]
          transition-all
        "
                >

                  {/* IMAGE */}
                  <div className="relative h-[210px] overflow-hidden">

                    <img
                      src={
                        property.image ||
                        "https://via.placeholder.com/400x300"
                      }
                      alt={property.title}
                      className="w-full h-full object-cover"
                    />

                    {/* GRADIENT */}
                    <div className="
            absolute inset-0
            bg-gradient-to-t
            from-black/50
            via-black/10
            to-transparent
          " />

                    {/* FEATURED */}
                    <div className="
            absolute top-4 left-4
            bg-primary
            text-white
            text-[11px]
            font-semibold
            px-3 py-1.5
            rounded-full
            shadow-lg
            backdrop-blur-sm
          ">
                      Featured
                    </div>

                    {/* RATING */}
                    <div className="
            absolute top-4 right-4
            bg-white/90
            backdrop-blur-md
            px-3 py-1.5
            rounded-full
            text-[12px]
            font-semibold
            flex items-center gap-1
            shadow-md
          ">
                      ⭐ 4.5
                    </div>

                    {/* BOTTOM INFO */}
                    <div className="
            absolute bottom-4 left-4 right-4
            text-white
          ">

                      <div className="
              text-[12px]
              font-medium
              opacity-90
              mb-1
            ">
                        {property.features?.extra?.construction_status ||
                          "Ready to Move"}
                      </div>

                      <h3 className="
              text-[22px]
              font-bold
              leading-tight
              line-clamp-2
            ">
                        {property.features?.extra?.project_name || property.title}
                      </h3>

                    </div>
                  </div>

                  {/* CONTENT */}
                  <div className="p-5">

                    {/* LOCATION */}
                    <div className="
            flex items-center gap-2
            text-sm text-gray-500
            mb-4
          ">
                      <MapPin className="w-4 h-4 text-primary" />

                      <span className="line-clamp-1">
                        {property.location}
                      </span>
                    </div>

                    {/* PRICE */}
                    <div className="mb-4">

                      <div className="
              text-[30px]
              font-bold
              text-[#0B1B3F]
              leading-none
            ">
                        ₹ {parseFloat(
                          String(property.price).replace(/[^0-9.]/g, "")
                        ).toFixed(1)} Cr
                      </div>

                      <div className="
              text-sm
              text-gray-400
              mt-2
            ">
                        {property.beds} BHK • {property.area} sqft
                      </div>
                    </div>

                    {/* DIVIDER */}
                    <div className="h-px bg-gray-100 mb-4" />

                    {/* ACTIONS */}
                    <div className="flex gap-3">

                      {/* SITE VISIT */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();

                          navigate(
                            `/property/${property.id}?siteVisit=true`
                          );
                        }}
                        className="
                flex-1
                h-12
                rounded-2xl
                border
                border-primary/20
                bg-primary/5
                text-primary
                text-sm
                font-semibold
                hover:bg-primary/10
                transition-all
              "
                      >
                        Site Visit
                      </button>

                      {/* CONTACT */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();

                          if (property.mobile) {
                            window.location.href = `tel:${property.mobile}`;
                          } else {
                            alert("Phone number not available");
                          }
                        }}
                        className="
                flex-1
                h-12
                rounded-2xl
                bg-primary
                text-white
                text-sm
                font-semibold
                shadow-lg
                hover:opacity-95
                transition-all
              "
                      >
                        Contact
                      </button>

                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Budget Friendly */}
        <div className="px-5 pt-7">

          {/* Heading */}
          <div className="flex items-center justify-between mb-5">

            <div>
              <h2 className="text-[24px] font-bold text-[#0B1B3F]">
                Budget Friendly
              </h2>

              <p className="text-[13px] text-gray-500 mt-1">
                Affordable luxury homes curated for you
              </p>
            </div>

          </div>

          {/* Horizontal Cards */}
          <div className="
    flex gap-5 overflow-x-auto
    scroll-smooth snap-x snap-mandatory
    pb-3 pr-5 no-scrollbar
  ">

            {filteredProperties
              .filter(
                (property) =>
                  property.listing_type === "budget"
              )
              .slice(0, 8)
              .map((property) => (

                <div
                  key={property.id}
                  onClick={() => navigate(`/property/${property.id}`)}
                  className="
            min-w-[280px]
            max-w-[280px]
            bg-white
            rounded-[26px]
            overflow-hidden
            border
            border-gray-100
            shadow-[0_6px_24px_rgba(0,0,0,0.06)]
            shrink-0
            snap-start
            cursor-pointer
            active:scale-[0.985]
            transition-all
          "
                >

                  {/* IMAGE */}
                  <div className="relative h-[185px] overflow-hidden">

                    <img
                      src={
                        property.image ||
                        "https://via.placeholder.com/500x300"
                      }
                      className="w-full h-full object-cover"
                    />

                    {/* Gradient Overlay */}
                    <div className="
              absolute inset-0
              bg-gradient-to-t
              from-black/45
              via-black/5
              to-transparent
            " />

                    {/* RERA */}
                    <div className="
              absolute top-4 left-4
              bg-[#00C2A8]
              text-white
              text-[11px]
              font-semibold
              px-3 py-1.5
              rounded-full
              shadow-md
            ">
                      ✓ RERA
                    </div>

                    {/* Wishlist */}
                    <button className="
              absolute top-4 right-4
              w-10 h-10
              rounded-full
              bg-white/90
              backdrop-blur-sm
              flex items-center justify-center
              shadow-lg
              text-lg
            ">
                      🤍
                    </button>

                    {/* Possession */}
                    <div className="
              absolute bottom-4 left-4
              text-white
            ">

                      <div className="
                text-[12px]
                opacity-90
                font-medium
              ">
                        Possession from
                      </div>

                      <div className="
                text-[18px]
                font-bold
              ">
                        Aug 2026
                      </div>

                    </div>

                  </div>

                  {/* CONTENT */}
                  <div className="p-5">
                    {/* Project Name */}
                    <h3 className="
  text-[18px]
  font-bold
  text-[#0B1B3F]
  leading-snug
  line-clamp-1
  truncate
  mb-2
">
                      {property.features?.extra?.project_name || property.title}
                    </h3>

                    {/* Location */}
                    <div className="
              flex items-center gap-2
              text-[14px]
              text-gray-500
              mb-3
            ">

                      <MapPin className="w-4 h-4 text-primary" />

                      <span className="line-clamp-1">
                        {property.location || "Sector 150, Noida"}
                      </span>

                    </div>

                    {/* Configuration */}
                    <div className="
              flex items-center justify-between
              mb-4
            ">

                      <div className="
                text-[13px]
                text-gray-400
              ">
                        {property.beds} BHK • {property.area} sqft
                      </div>

                      <div className="
                px-3 py-1
                rounded-full
                bg-primary/10
                text-primary
                text-[11px]
                font-semibold
              ">
                        Budget Deal
                      </div>

                    </div>

                    {/* Divider */}
                    <div className="h-px bg-gray-100 mb-4" />

                    {/* Bottom */}
                    <div className="
              flex items-end justify-between
            ">

                      {/* Price */}
                      <div>

                        <div className="
                  text-[30px]
                  font-bold
                  text-[#0B1B3F]
                  leading-none
                ">
                          ₹ {parseFloat(
                            String(property.price).replace(/[^0-9.]/g, "")
                          ).toFixed(2)} Cr
                        </div>

                        <div className="
                  text-[11px]
                  text-gray-400
                  mt-1
                ">
                          onwards
                        </div>

                      </div>

                      {/* CTA */}
                      <div className="
                px-4 py-2
                rounded-2xl
                bg-primary
                text-white
                text-[12px]
                font-semibold
                shadow-md
              ">
                        View
                      </div>

                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Nearby */}
        <div className="px-5 pt-7">

          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-[22px] font-bold text-[#0B1B3F]">
                Nearby your location
              </h2>

              <p className="text-[13px] text-gray-500 mt-1">
                Handpicked properties near you
              </p>
            </div>
          </div>

          {/* Premium Grid */}
          <div className="grid grid-cols-2 gap-4">

            {filteredProperties
              .filter(
                (property) =>
                  property.listing_type === "normal"
              )
              .slice(0, 8)
              .map((property) => (

                <div
                  key={property.id}
                  onClick={() => navigate(`/property/${property.id}`)}
                  className="
            bg-white
            rounded-[22px]
            overflow-hidden
            border
            border-gray-100
            shadow-[0_4px_18px_rgba(0,0,0,0.05)]
            active:scale-[0.98]
            transition-all
          "
                >

                  {/* IMAGE */}
                  <div className="relative h-[130px] overflow-hidden">

                    <img
                      src={property.image}
                      className="w-full h-full object-cover"
                    />

                    {/* GRADIENT */}
                    <div className="
              absolute inset-0
              bg-gradient-to-t
              from-black/40
              to-transparent
            " />

                    {/* RERA */}
                    <div className="
              absolute top-2 left-2
              bg-[#00C2A8]
              text-white
              text-[10px]
              font-semibold
              px-2 py-1
              rounded-md
              backdrop-blur-sm
            ">
                      ✓ RERA
                    </div>

                    {/* HEART */}
                    <button className="
              absolute top-2 right-2
              w-8 h-8
              rounded-full
              bg-white/90
              flex items-center justify-center
              text-sm
              shadow-md
            ">
                      🤍
                    </button>

                    {/* LOCATION */}
                    <div className="
              absolute bottom-2 left-2
              text-white
              text-[11px]
              font-medium
              line-clamp-1
            ">
                      {property.location || "Gurgaon"}
                    </div>
                  </div>

                  {/* CONTENT */}
                  <div className="p-3">

                    <h3 className="
              text-[14px]
              font-bold
              text-[#0B1B3F]
              line-clamp-1
              mb-1
            ">
                      {property.features?.extra?.project_name || property.title}
                    </h3>

                    <p className="
              text-[11px]
              text-gray-500
              line-clamp-1
              mb-3
            ">
                      Premium Apartments
                    </p>

                    {/* PRICE */}
                    <div className="flex items-end justify-between">

                      <div>
                        <div className="
                  text-[18px]
                  font-bold
                  text-[#0B1B3F]
                  leading-none
                ">
                          ₹ {parseFloat(
                            String(property.price).replace(/[^0-9.]/g, "")
                          ).toFixed(1)} Cr
                        </div>

                        <div className="
                  text-[10px]
                  text-gray-400
                  mt-1
                ">
                          onwards
                        </div>
                      </div>

                      {/* CTA */}
                      <div className="
                px-3 py-1.5
                rounded-full
                bg-primary/10
                text-primary
                text-[11px]
                font-semibold
              ">
                        View
                      </div>

                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      <div className="pb-[env(safe-area-inset-bottom)]">
        <BottomNav />
      </div>

      {/* FILTER DRAWER */}
      <div
        className={`fixed inset-0 z-50 flex transition-all duration-300 ${isFilterOpen
          ? "bg-black/40 opacity-100"
          : "bg-black/0 opacity-0 pointer-events-none"
          }`}
      >

        {/* Outside Click */}
        <div
          className="flex-1"
          onClick={() => setIsFilterOpen(false)}
        />

        {/* Drawer */}
        <div
          className={`w-[85%] max-w-sm bg-white h-full flex flex-col transition-all duration-300 ${isFilterOpen
            ? "translate-x-0"
            : "translate-x-full"
            }`}
        >

          {/* Header */}
          <div className="p-5 border-b border-gray-100 flex items-center justify-between">
            <h2 className="text-lg font-semibold">
              Filters
            </h2>

            <button
              onClick={() => setIsFilterOpen(false)}
              className="text-xl text-gray-400"
            >
              ✕
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-5">

            {/* Sort */}
            <div className="mb-7">
              <p className="font-semibold mb-3">
                Sort By
              </p>

              <div className="space-y-3">

                {[
                  {
                    label: "Price Low to High",
                    value: "lowToHigh",
                  },
                  {
                    label: "Price High to Low",
                    value: "highToLow",
                  },
                ].map((option) => (

                  <button
                    key={option.value}
                    onClick={() => setSortBy(option.value)}
                    className={`
                    w-full
                    h-11
                    rounded-2xl
                    border
                    text-sm
                    ${sortBy === option.value
                        ? "bg-primary text-white border-primary"
                        : "border-gray-200"
                      }
                  `}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            {/* City */}
            <div className="mb-4">
              <p className="mb-2 font-medium">
                City
              </p>

              <div className="flex flex-wrap gap-2">
                {cities.map((city) => (
                  <button
                    key={city}
                    onClick={() => toggleFilter(city)}
                    className={` px-4 py-2 rounded-full border text-sm transition-all ${selectedFilters.includes(city)
                      ? "bg-primary text-white border-primary"
                      : "bg-white border-gray-200 text-gray-700"
                      } `}
                  >
                    {city}
                  </button>
                ))}
              </div>
            </div>

            {/* Location */}
            {/* <div className="mb-4">
              <p className="mb-2 font-medium">
                Location
              </p>

              <div className="flex flex-wrap gap-2">
                {locations.map((loc) => (
                  <button
                    key={loc}
                    onClick={() => toggleFilter(loc)}
                    className={` px-4 py-2 rounded-full border text-sm transition-all ${selectedFilters.includes(loc)
                      ? "bg-primary text-white border-primary"
                      : "bg-white border-gray-200 text-gray-700"
                      } `}
                  >
                    {loc}
                  </button>
                ))}
              </div>
            </div> */}

            {/* Project */}
            <div className="mb-4">
              <p className="mb-2 font-medium">
                Project
              </p>

              <div className="flex flex-wrap gap-2">
                {projects.map((project) => (
                  <button
                    key={project}
                    onClick={() => toggleFilter(project)}
                    className={` px-4 py-2 rounded-full border text-sm transition-all ${selectedFilters.includes(project)
                      ? "bg-primary text-white border-primary"
                      : "bg-white border-gray-200 text-gray-700"
                      }`}
                  >
                    {project}
                  </button>
                ))}
              </div>
            </div>

            {/* Builder */}
            <div className="mb-4">
              <p className="mb-2 font-medium">
                Builder
              </p>

              <div className="flex flex-wrap gap-2">
                {builders.map((builder) => (
                  <button
                    key={builder}
                    onClick={() => toggleFilter(builder)}
                    className={`
          px-4
          py-2
          rounded-full
          border
          text-sm
          transition-all
          ${selectedFilters.includes(builder)
                        ? "bg-primary text-white border-primary"
                        : "bg-white border-gray-200 text-gray-700"
                      }
        `}
                  >
                    {builder}
                  </button>
                ))}
              </div>
            </div>

            {/* BHK */}
            <div className="mb-7">
              <p className="font-semibold mb-3">
                BHK Type
              </p>

              <div className="flex flex-wrap gap-2">

                {["2 BHK", "3 BHK", "4 BHK"].map((chip) => (

                  <button
                    key={chip}
                    onClick={() => toggleFilter(chip)}
                    className={`
                    px-4
                    h-10
                    rounded-2xl
                    border
                    text-sm
                    ${selectedFilters.includes(chip)
                        ? "bg-primary text-white border-primary"
                        : "border-gray-200 bg-white"
                      }
                  `}
                  >
                    {chip}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div className="mb-7">

              <p className="text-[18px] font-semibold text-gray-900 mb-5">
                Filter By Price
              </p>

              {/* Current Range */}
              <p className="text-gray-500 text-sm mb-5">
                Current Range:
                <span className="font-semibold text-gray-800">
                  {" "}₹{priceRange[0]} Cr - ₹{priceRange[1]} Cr
                </span>
              </p>

              <div className="relative">

                {/* Slider */}
                <input
                  type="range"
                  min="2"
                  max="15"
                  step="1"
                  value={priceRange[1]}
                  onChange={(e) =>
                    setPriceRange([2, Number(e.target.value)])
                  }
                  className="w-full h-2 rounded-full appearance-none cursor-pointer accent-primary
"
                />

                {/* Numbers */}

              </div>
            </div>

            {/* Furnishing */}
            <div className="mb-6">
              <p className="text-[16px] font-semibold text-gray-900 mb-3">
                Furnishing
              </p>

              <div className="flex flex-wrap gap-2">
                {["Furnished", "Semi Furnished", "Unfurnished"].map((f) => (
                  <button
                    key={f}
                    onClick={() => toggleFilter(f)}
                    className={`
          px-4
          py-2
          rounded-2xl
          border
          text-sm
          transition-all
          duration-200
          ${selectedFilters.includes(f)
                        ? "bg-primary text-white border-primary shadow-sm"
                        : "bg-white border-gray-200 text-gray-700"
                      }
        `}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            {/* Construction */}
            <div className="mb-6">
              <p className="text-[16px] font-semibold text-gray-900 mb-3">
                Construction Status
              </p>

              <div className="flex flex-wrap gap-2">
                {["Ready to Move", "Under Construction"].map((s) => (
                  <button
                    key={s}
                    onClick={() => toggleFilter(s)}
                    className={`
          px-4
          py-2
          rounded-2xl
          border
          text-sm
          transition-all
          duration-200
          ${selectedFilters.includes(s)
                        ? "bg-primary text-white border-primary shadow-sm"
                        : "bg-white border-gray-200 text-gray-700"
                      }
        `}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Amenities */}
            <div className="mb-6">
              <p className="text-[16px] font-semibold text-gray-900 mb-3">
                Amenities
              </p>

              <div className="flex flex-wrap gap-2">
                {["Parking", "Gym", "Lift", "Swimming Pool"].map((a) => (
                  <button
                    key={a}
                    onClick={() => toggleFilter(a)}
                    className={`
          px-4
          py-2
          rounded-2xl
          border
          text-sm
          transition-all
          duration-200
          ${selectedFilters.includes(a)
                        ? "bg-primary text-white border-primary shadow-sm"
                        : "bg-white border-gray-200 text-gray-700"
                      }
        `}
                  >
                    {a}
                  </button>
                ))}
              </div>
            </div>
          </div>



          {/* Footer */}
          <div className="p-5 border-t border-gray-100 flex gap-3">

            <button
              onClick={() => {
                setSelectedFilters([]);
                setSortBy("");
              }}
              className="
              flex-1
              h-12
              rounded-2xl
              border
              border-gray-200
              font-medium
            "
            >
              Clear
            </button>

            <button
              onClick={() => setIsFilterOpen(false)}
              className="
              flex-1
              h-12
              rounded-2xl
              bg-primary
              text-white
              font-medium
            "
            >
              Apply
            </button>
          </div>
        </div>
      </div>
    </div >
  );
}