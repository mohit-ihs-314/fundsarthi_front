import { useState } from "react";
import { useNavigate } from "react-router";
import { GradientButton } from "../../components/ui/gradient-button";
import { Input } from "../../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { ArrowLeft } from "lucide-react";

export default function ProfileSetup() {
  const [formData, setFormData] = useState({
    fullName: "",
    city: "",
    employment: "",
    income: "",
  });
  const navigate = useNavigate();

  const handleContinue = () => {
    if (formData.fullName && formData.city && formData.employment && formData.income) {
      // Save profile data to localStorage
      localStorage.setItem('userProfile', JSON.stringify({
        fullName: formData.fullName,
        city: formData.city,
        employment: formData.employment,
        income: formData.income,
      }));
      navigate("/home");
    }
  };

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="px-6 py-4 flex items-center border-b border-border">
        <button onClick={() => navigate(-1)} className="text-foreground">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="ml-4">Complete Your Profile</h1>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-6 overflow-y-auto">
        <p className="text-muted-foreground mb-6">
          Help us serve you better by completing your profile
        </p>

        <div className="space-y-4">
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">
              Full Name
            </label>
            <Input
              placeholder="Enter your full name"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              className="h-12 rounded-xl"
            />
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-2 block">
              City
            </label>
            <Select
              value={formData.city}
              onValueChange={(value) => setFormData({ ...formData, city: value })}
            >
              <SelectTrigger className="h-12 rounded-xl">
                <SelectValue placeholder="Select your city" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mumbai">Mumbai</SelectItem>
                <SelectItem value="delhi">Delhi</SelectItem>
                <SelectItem value="bangalore">Bangalore</SelectItem>
                <SelectItem value="pune">Pune</SelectItem>
                <SelectItem value="hyderabad">Hyderabad</SelectItem>
                <SelectItem value="chennai">Chennai</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-2 block">
              Employment Type
            </label>
            <Select
              value={formData.employment}
              onValueChange={(value) => setFormData({ ...formData, employment: value })}
            >
              <SelectTrigger className="h-12 rounded-xl">
                <SelectValue placeholder="Select employment type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="salaried">Salaried</SelectItem>
                <SelectItem value="self-employed">Self Employed</SelectItem>
                <SelectItem value="business">Business Owner</SelectItem>
                <SelectItem value="professional">Professional</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm text-muted-foreground mb-2 block">
              Monthly Income
            </label>
            <Input
              type="text"
              placeholder="Enter monthly income"
              value={formData.income}
              onChange={(e) => {
                const value = e.target.value.replace(/\D/g, "");
                setFormData({ ...formData, income: value });
              }}
              className="h-12 rounded-xl"
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 py-4 border-t border-border">
        <GradientButton
          onClick={handleContinue}
          className="w-full"
          disabled={!formData.fullName || !formData.city || !formData.employment || !formData.income}
        >
          Continue
        </GradientButton>
      </div>
    </div>
  );
}