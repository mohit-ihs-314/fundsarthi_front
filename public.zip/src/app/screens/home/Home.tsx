import { useNavigate } from "react-router";
import { BottomNav } from "../../components/BottomNav";
import { GradientButton } from "../../components/ui/gradient-button";
import { getInitials, getGreeting } from "../../utils/helpers";
import { Bell, MapPin, TrendingUp, Building2, Compass, Users, Calculator, FileText, CreditCard } from "lucide-react";
import { useState, useEffect } from "react";
import { CompleteProfileModal } from "../../components/CompleteProfileModal";

export default function Home() {
  const navigate = useNavigate();
  useEffect(() => {
    const fetchLoanStatus = async () => {
      const mobile = localStorage.getItem("userMobile");

      if (!mobile) return;

      try {
        const res = await fetch(`https://fundsarthi.onrender.com/api/loan-status?mobile=${mobile}`);
        const data = await res.json();

        if (data.status === "success") {
          setHasLoan(data.hasLoan);
          setLoanSteps(data.data);

          // 🔥 progress calculate
          const doneSteps = data.data.filter(step => step.done).length;
          const totalSteps = data.data.length;
          setloanProgress((doneSteps / totalSteps) * 100);
        }

      } catch (err) {
        console.error(err);
      }
    };

    fetchLoanStatus();
  }, []);
  const [loanprogress, setloanProgress] = useState(0);
  const [loanSteps, setLoanSteps] = useState([]);
  const progress =
    loanSteps.length > 0
      ? (loanSteps.filter(step => step.done).length / loanSteps.length) * 100
      : 0;
  const [hasLoan, setHasLoan] = useState(false);


  useEffect(() => {
    const fetchUser = async () => {
      const mobile = localStorage.getItem("userMobile");

      if (!mobile) return;

      try {
        const res = await fetch(`https://fundsarthi.onrender.com/api/user-profile?mobile=${mobile}`);
        const data = await res.json();

        if (data.status === "success") {
          setUser(data.data);
        }

      } catch (err) {
        console.error("Error fetching user:", err);
      }
    };

    fetchUser();
  }, []);
  const [user, setUser] = useState(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Mock user data - in real app this would come from context/state
  const userName = user?.name || "User";
  const currentCity =
    localStorage.getItem("userCity");

  const currentLocality =
    localStorage.getItem("userLocality");

  const [liveLocation, setLiveLocation] =
    useState("Select Location");

  useEffect(() => {

    const updateLocation = () => {

      const city =
        localStorage.getItem("userCity");

      const locality =
        localStorage.getItem("userLocality");

      if (locality && city) {
        setLiveLocation(`${locality}, ${city}`);
      }
      else if (city) {
        setLiveLocation(city);
      }
      else if (user?.city) {
        setLiveLocation(user.city);
      }
    };

    updateLocation();

    window.addEventListener(
      "locationUpdated",
      updateLocation
    );

    return () => {
      window.removeEventListener(
        "locationUpdated",
        updateLocation
      );
    };

  }, [user]);

  const initials = getInitials(userName);
  const greeting = getGreeting();

  const checkProfileAndNavigate = (path: string) => {
    const isLoanPage = path.includes('/loan') || path === '/loans';

    // ✅ Backend se aaya user check karo
    if (
      isLoanPage &&
      (!user?.name || !user?.city || !user?.employment)
    ) {
      setShowProfileModal(true);
    } else {
      navigate(path);
    }
  };

  const handleCompleteProfile = () => {
    setShowProfileModal(false);
    navigate('/profile');
  };

  const banners = [
    {
      title: "Get Home Loan up to ₹50L",
      subtitle: "Low interest rates available",
      path: "/loans",
    },
    {
      title: "Find Your Dream Property",
      subtitle: "Verified listings in your area",
      path: "/property",
    },
    {
      title: "Check Loan Eligibility",
      subtitle: "Know your eligibility instantly",
      path: "/calculator/eligibility",
    },
  ];

  const [bannerIndex, setBannerIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setBannerIndex((prev) => (prev + 1) % banners.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-full flex flex-col bg-background">

      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/40 z-40 transition-opacity duration-300 ${sidebarOpen ? "opacity-100 visible" : "opacity-0 invisible"
          }`}
        onClick={() => setSidebarOpen(false)}
      />

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full w-[82%] max-w-[320px] bg-white z-50 shadow-2xl transform transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"
          }`}
      >
        {/* Header */}
        <div className="bg-[var(--primary)] text-white p-5">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center text-lg font-bold">
              {initials}
            </div>

            <div>
              <h2 className="text-lg font-semibold">{userName}</h2>
              <p className="text-sm text-white/80">{liveLocation}</p>
            </div>
          </div>
        </div>

        {/* Menu */}
        <div className="flex flex-col h-full">

          {/* Top Menu */}
          <div className="p-4 space-y-2 flex-1 overflow-y-auto">

            {/* Profile */}
            <button
              onClick={() => {
                navigate("/profile");
                setSidebarOpen(false);
              }}
              className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-gray-100 active:scale-[0.98] transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-[var(--primary)]" />
              </div>

              <div className="flex-1 text-left">
                <p className="text-sm font-medium">My Profile</p>
                <p className="text-xs text-muted-foreground">
                  Manage your account
                </p>
              </div>
            </button>

            {/* Manage Listings */}
            <button
              onClick={() => {
                navigate("/my-properties");
                setSidebarOpen(false);
              }}
              className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-gray-100 active:scale-[0.98] transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-[var(--primary)]" />
              </div>

              <div className="flex-1 text-left">
                <p className="text-sm font-medium">Manage Listings</p>
                <p className="text-xs text-muted-foreground">
                  Your posted properties
                </p>
              </div>
            </button>

            {/* Loan Status */}
            <button
              onClick={() => {
                navigate("/my-applications");
                setSidebarOpen(false);
              }}
              className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-gray-100 active:scale-[0.98] transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-[var(--primary)]" />
              </div>

              <div className="flex-1 text-left">
                <p className="text-sm font-medium">Loan Status</p>
                <p className="text-xs text-muted-foreground">
                  Track your applications
                </p>
              </div>
            </button>

            {/* Saved Properties */}
            {/* <button
              onClick={() => {
                navigate("/saved-properties");
                setSidebarOpen(false);
              }}
              className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-gray-100 active:scale-[0.98] transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
                <Compass className="w-5 h-5 text-[var(--primary)]" />
              </div>

              <div className="flex-1 text-left">
                <p className="text-sm font-medium">Saved Properties</p>
                <p className="text-xs text-muted-foreground">
                  Wishlist & shortlisted
                </p>
              </div>
            </button> */}

            {/* My Consultations */}
            <button
              onClick={() => {
                navigate("/my-consultations");
                setSidebarOpen(false);
              }}
              className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-gray-100 active:scale-[0.98] transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
                <Calculator className="w-5 h-5 text-[var(--primary)]" />
              </div>

              <div className="flex-1 text-left">
                <p className="text-sm font-medium">My Consultations</p>
                <p className="text-xs text-muted-foreground">
                  Your scheduled consultations
                </p>
              </div>
            </button>

            {/* Logout */}
            <button
              onClick={() => {
                localStorage.clear();
                navigate("/login");
              }}
              className="w-full flex items-center gap-4 p-4 rounded-2xl text-red-500 hover:bg-red-50 active:scale-[0.98] transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-red-100 flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>

              <div className="flex-1 text-left">
                <p className="text-sm font-medium">Logout</p>
                <p className="text-xs text-red-400">
                  Securely sign out
                </p>
              </div>
            </button>

            

          </div>

          {/* Bottom Section */}
          <div className="p-4 border-t border-border space-y-3">

            {/* Complete Profile */}
            <div className="bg-primary/5 border border-primary/10 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium">
                  Complete Profile
                </p>

                <p className="text-xs text-[var(--primary)] font-semibold">
                  80%
                </p>
              </div>

              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full w-[80%] bg-[var(--primary)] rounded-full" />
              </div>

              <button
                onClick={() => {
                  navigate("/profile");
                  setSidebarOpen(false);
                }}
                className="mt-3 text-xs font-medium text-[var(--primary)]"
              >
                Update Now →
              </button>
            </div>

            

          </div>
        </div>
      </div>

      {/* Header */}
      <div className="px-6 py-4 bg-card border-b border-border">
        <div className="flex items-center justify-between">
          {/* Profile Section */}
          <div className="flex items-center gap-3">
            {/* Avatar with Initials */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="w-12 h-12 rounded-full bg-gradient-to-br from-accent to-primary flex items-center justify-center shadow-md active:scale-90 transition-all duration-150"
            >
              <span className="text-white font-semibold text-lg">{initials}</span>
            </button>

            {/* User Info */}
            <div>
              <p className="text-xs text-muted-foreground">{greeting}</p>
              <h2 className="text-base">{userName}</h2>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="w-3 h-3" />
                <span>{liveLocation}</span>
              </div>
            </div>
          </div>

          {/* Notification Bell */}
          <button className="w-10 h-10 rounded-full bg-background flex items-center justify-center hover:bg-muted transition-colors">
            <Bell className="w-5 h-5 text-foreground" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">


        <div className="px-4 pt-4 pb-4">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-out"
              style={{
                transform: `translateX(-${bannerIndex * 100}%)`,
              }}
            >
              {banners.map((banner, i) => (
                <div
                  key={i}
                  className="min-w-full px-1"
                >
                  <div
                    onClick={() => navigate(banner.path)}
                    className="
                      relative overflow-hidden
                      rounded-[26px]
                      px-5
                      py-5
                      min-h-[170px]
                      bg-[var(--primary)]
                      text-white
                      shadow-xl
                      active:scale-[0.98]
                      transition-all
                    "
                  >

                    {/* Glow Effects */}
                    <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
                    <div className="absolute bottom-0 left-0 w-28 h-28 bg-black/10 rounded-full blur-2xl" />

                    {/* Small Tag */}
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur text-[11px] font-medium mb-4 border border-white/10">
                      ✨ Trusted by 10,000+ users
                    </div>

                    {/* Heading */}
                    <h2 className="text-[20px] leading-tight font-bold max-w-[210px] mb-2">
                      {banner.title}
                    </h2>

                    {/* Subtitle */}
                    <p className="text-[13px] text-white/75 max-w-[190px] leading-relaxed mb-4">
                      {banner.subtitle}
                    </p>

                    {/* CTA */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(banner.path);
                      }}
                      className="
                        h-9
                        px-4
                        rounded-full
                        bg-white
                        text-[var(--primary)]
                        text-[13px]
                        font-semibold
                        shadow-md
                        active:scale-95
                        transition-all
                      "
                    >
                      {bannerIndex === 0 && "Apply Now"}
                      {bannerIndex === 1 && "View Properties"}
                      {bannerIndex === 2 && "Check Eligibility"}
                    </button>

                    {/* Decorative Right Element */}
                    <div className="absolute right-4 bottom-4 opacity-10">
                      {i === 0 && (
                        <TrendingUp className="w-20 h-20" />
                      )}

                      {i === 1 && (
                        <Building2 className="w-20 h-20" />
                      )}

                      {i === 2 && (
                        <Calculator className="w-20 h-20" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-4">
            {banners.map((_, i) => (
              <div
                key={i}
                className={`
          transition-all duration-300 rounded-full
          ${i === bannerIndex
                    ? "w-6 h-2 bg-[var(--primary)]"
                    : "w-2 h-2 bg-gray-300"
                  }
        `}
              />
            ))}
          </div>
        </div>

        <div className="px-6 mb-4">
          <div className="bg-accent/10 border border-accent/20 rounded-xl p-4">

            <p className="text-sm font-medium">
              💡 You may be eligible for a home loan of {user?.eligible_amount || "0"}
            </p>

            <p className="text-xs text-muted-foreground mt-1">
              Based on your profile & income
            </p>

          </div>
        </div>

        {/* Quick Actions */}
        <div className="px-6 mb-6">
          <h3 className="mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => checkProfileAndNavigate("/loans")}
              className="bg-card rounded-2xl p-4 border border-border hover:shadow-md transition-shadow flex flex-col items-center text-center"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-3">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>

              <p className="text-sm">Apply For Loan</p>
            </button>

            <button
              onClick={() => checkProfileAndNavigate("/property")}
              className="bg-card rounded-2xl p-4 border border-border hover:shadow-md transition-shadow flex flex-col items-center text-center"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-3">
                <Building2 className="w-6 h-6 text-primary" />
              </div>

              <p className="text-sm">Explore Properties</p>
            </button>

            <button
              onClick={() => checkProfileAndNavigate("/vastu")}
              className="bg-card rounded-2xl p-4 border border-border hover:shadow-md transition-shadow flex flex-col items-center text-center"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-3">
                <Compass className="w-6 h-6 text-primary" />
              </div>

              <p className="text-sm">Connect with Vastu Expert</p>
            </button>

            <button
              onClick={() => checkProfileAndNavigate("/become-partner")}
              className="bg-card rounded-2xl p-4 border border-border hover:shadow-md transition-shadow flex flex-col items-center text-center"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-3">
                <Users className="w-6 h-6 text-primary" />
              </div>

              <p className="text-sm">Become a Partner</p>
            </button>
          </div>
        </div>



        {/* Calculators */}
        <div className="px-6 mb-6">
          <h3 className="mb-4">Financial Calculators</h3>
          <div className="space-y-3">
            <button
              onClick={() => navigate("/calculator/emi")}
              className="w-full bg-card rounded-xl p-4 border border-border flex items-center gap-4 hover:shadow-md transition-shadow"
            >
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Calculator className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm">EMI Calculator</p>
                <p className="text-xs text-muted-foreground">Calculate monthly payments</p>
              </div>
            </button>

            <button
              onClick={() => navigate("/calculator/eligibility")}
              className="w-full bg-card rounded-xl p-4 border border-border flex items-center gap-4 hover:shadow-md transition-shadow"
            >
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm">Eligibility Calculator</p>
                <p className="text-xs text-muted-foreground">Check loan eligibility</p>
              </div>
            </button>

            <button
              onClick={() => navigate("/calculator/credit-score")}
              className="w-full bg-card rounded-xl p-4 border border-border flex items-center gap-4 hover:shadow-md transition-shadow"
            >
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm">Credit Score Estimator</p>
                <p className="text-xs text-muted-foreground">Estimate your credit score</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      <BottomNav />
      <CompleteProfileModal
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
        onCompleteProfile={handleCompleteProfile}
      />
    </div>
  );
}