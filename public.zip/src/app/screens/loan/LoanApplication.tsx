import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { GradientButton } from "../../components/ui/gradient-button";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { ArrowLeft, Lock, Edit2 } from "lucide-react";

export default function LoanApplication() {
  const { type } = useParams();
  const navigate = useNavigate();

  // Load user profile data
  const [userProfile, setUserProfile] = useState({
    fullName: "",
    mobile: "+91 98XXXXXX21", // Mock mobile from OTP login
  });


  const [formData, setFormData] = useState({
    amount: "",
    existingEmi: "",
    notes: "",
    cr_name: userProfile.fullName,
    cr_number: userProfile.mobile,

    // 🔥 dynamic fields
    companyName: "",
    salary: "",
    creditCardDue: "",
    propertyType: "",
    projectName: "",
    incomeType: "",
    propertyValue: "",
    propertyLocation: "",
    businessType: "",
    turnover: "",
    gst: "",
    requirementType: "",
    entityType: "",
    businessName: ""
  });

  const loanFieldsConfig = {
    personal: ["companyName", "salary", "creditCardDue"],
    home: ["propertyType", "projectName", "incomeType"],
    lap: ["propertyValue", "propertyLocation"],
    business: ["businessType", "turnover", "gst"],
    corporate: ["requirementType", "turnover"],
    msme: ["entityType", "businessName", "turnover"]
  };

  const [loadingUser, setLoadingUser] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      const mobile = localStorage.getItem("userMobile");

      if (!mobile) {
        navigate("/");
        return;
      }

      try {
        const res = await fetch(`https://fundsarthi.onrender.com/api/user-profile?mobile=${mobile}`);
        const data = await res.json();

        if (data.status === "success") {
          setUserProfile({
            fullName: data.data.name,
            mobile: mobile,
          });

          // ✅ profile validation yahan karo
          if (!data.data.name || !data.data.city || !data.data.employment) {
            navigate("/profile");
          }

        } else {
          navigate("/profile");
        }

      } catch (err) {
        console.error(err);
      } finally {
        setLoadingUser(false);
      }
    };

    fetchUser();
  }, []);



  const handleSubmit = async () => {
    const mobile = localStorage.getItem("userMobile");

    if (!mobile) {
      alert("Session expired");
      navigate("/");
      return;
    }

    try {
      const res = await fetch("https://fundsarthi.onrender.com/api/apply-loan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          mobile,
          amount: formData.amount,
          existingEmi: formData.existingEmi,
          notes: formData.notes,
          cr_name: userProfile.fullName,
          cr_number: userProfile.mobile,
          type,
          formData
        })
      });

      const data = await res.json();

      if (data.status === "success") {
        navigate(`/application-success/${data.application_id}`);
      } else {
        alert(data.message);
      }

    } catch (err) {
      console.error(err);
      alert("Server error");
    }
  };

  const amountOptions = [
    "Upto 5 L",
    "5 to 10 L",
    "10 to 15 L",
    "15 to 20 L",
    "20 to 50 L",
    "50 to 1 Cr",
    "1 Cr +"
  ];

  const getLoanTitle = () => {
    const titles: Record<string, string> = {
      home: "Home Loan",
      personal: "Personal Loan",
      car: "Car Loan",
      education: "Education Loan",
      business: "Business Loan",
      "credit-card": "Credit Card",
    };
    return titles[type || ""] || "Loan";
  };

  const dynamicFields = loanFieldsConfig[type] || [];

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="px-6 py-4 bg-card border-b border-border flex items-center">
        <button onClick={() => navigate(-1)} className="text-foreground">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="ml-4">{getLoanTitle()}</h1>
      </div>

      {/* Progress Bar */}
      <div className="px-6 py-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">Step 1 of 3</span>
          <span className="text-sm text-primary">33% Complete</span>
        </div>
        <div className="h-2 bg-muted rounded-full">
          <div className="h-full w-1/3 bg-primary rounded-full" />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        <div className="space-y-5">
          {/* User Info Section - Auto-filled */}
          <div className="bg-card rounded-2xl p-5 border border-border">
            <p className="text-sm text-muted-foreground mb-4">Your Details</p>

            <div className="space-y-4">
              <div className="relative">
                <label className="text-sm text-muted-foreground mb-2 block">
                  Full Name
                </label>
                <div className="relative">
                  <Input
                    value={userProfile.fullName}
                    onChange={(e) => setUserProfile({ ...userProfile, fullName: e.target.value })}
                    className="h-12 rounded-xl pr-10"
                  />
                  <Edit2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                </div>
              </div>

              <div className="relative">
                <label className="text-sm text-muted-foreground mb-2 block">
                  Mobile Number
                </label>
                <div className="relative">
                  <Input
                    value={userProfile.mobile}
                    disabled
                    className="h-12 rounded-xl pr-10 bg-muted/50 cursor-not-allowed"
                  />
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                </div>
              </div>
            </div>
          </div>

          {/* Loan Details Section */}
          <div>
            <p className="text-sm text-muted-foreground mb-4">Loan Details</p>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">
                  Loan Amount
                </label>

                <select
                  value={formData.amount}
                  onChange={(e) =>
                    setFormData({ ...formData, amount: e.target.value })
                  }
                  className="w-full h-12 rounded-xl border border-border bg-background px-3"
                >
                  <option value="">Select Amount</option>
                  {amountOptions.map((amt, i) => (
                    <option key={i} value={amt}>
                      {amt}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">
                  Existing EMI (if any)
                </label>
                <Input
                  type="text"
                  placeholder="Enter existing EMI or 0"
                  value={formData.existingEmi}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, "");
                    setFormData({ ...formData, existingEmi: value });
                  }}
                  className="h-12 rounded-xl"
                />
              </div>

              {dynamicFields.includes("companyName") && (
                <Input
                  placeholder="Company Name"
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                />
              )}

              {dynamicFields.includes("salary") && (
                <Input
                  placeholder="Net Salary"
                  value={formData.salary}
                  onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
                />
              )}

              {dynamicFields.includes("propertyType") && (
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">
                    Property Type
                  </label>

                  <select
                    value={formData.propertyType}
                    onChange={(e) =>
                      setFormData({ ...formData, propertyType: e.target.value })
                    }
                    className="w-full h-12 rounded-xl border border-border bg-background px-3"
                  >
                    <option value="">Select Property Type</option>
                    <option value="new">New</option>
                    <option value="resale">Resale</option>
                  </select>
                </div>
              )}

              {dynamicFields.includes("turnover") && (
                <Input
                  placeholder="Annual Turnover"
                  value={formData.turnover}
                  onChange={(e) => setFormData({ ...formData, turnover: e.target.value })}
                />
              )}

              {dynamicFields.includes("requirementType") && (
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">
                    Requirement Type
                  </label>

                  <select
                    value={formData.requirementType}
                    onChange={(e) =>
                      setFormData({ ...formData, requirementType: e.target.value })
                    }
                    className="w-full h-12 rounded-xl border border-border bg-background px-3"
                  >
                    <option value="">Select Requirement</option>
                    <option value="secured">Secured</option>
                    <option value="unsecured">Unsecured</option>
                  </select>
                </div>
              )}

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">
                  Additional Notes (Optional)
                </label>
                <Textarea
                  placeholder="Any specific requirements or information"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="h-24 rounded-xl resize-none"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 py-4 border-t border-border">
        <GradientButton
          onClick={handleSubmit}
          className="w-full"
          disabled={!formData.amount || !formData.existingEmi}
        >
          Continue
        </GradientButton>
      </div>
    </div>
  );
}