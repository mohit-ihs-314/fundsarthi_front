import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { ArrowLeft, MapPin, Star, BadgeCheck, Languages, Award } from "lucide-react";
import { GradientButton } from "../../components/ui/gradient-button";

export default function ExpertDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [expert, setExpert] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  // ✅ TIME SLOTS
  const [slotTimes, setSlotTimes] = useState<any[]>([]);
  const [dates, setDates] = useState<any[]>([]);

  // ✅ FETCH EXPERT
  useEffect(() => {
    fetch(`https://fundsarthi.onrender.com/api/consultant/${id}`)
      .then(res => res.json())
      .then(data => {
        if (data.status === "success") {
          setExpert(data.data);
        }
      })
      .catch(err => console.error(err));
  }, [id]);


  useEffect(() => {

    fetch(
      `https://fundsarthi.onrender.com/api/consultant-available-dates?consultant_id=${id}`
    )
      .then(res => res.json())
      .then(data => {

        if (data.status === "success") {

          const formattedDates = data.data.map((date: string) => {

            const d = new Date(date);

            return {
              value: date,
              display: {
                date: d.getDate(),
                day:
                  date === new Date().toISOString().split("T")[0]
                    ? "Today"
                    : d.toLocaleDateString(
                      "en-US",
                      { weekday: "short" }
                    ),
                month: d.toLocaleDateString(
                  "en-US",
                  { month: "short" }
                )
              }
            };

          });

          setDates(formattedDates);

        }

      })
      .catch(err => console.error(err));

  }, [id]);

  // ✅ SAFE DATA
  const languages =
    typeof expert?.languages === "string"
      ? expert.languages.split(",")
      : expert?.languages || [];

  const expertiseList =
    typeof expert?.expertise === "string"
      ? JSON.parse(expert.expertise)
      : expert?.expertise || [];





  useEffect(() => {

    if (!selectedDate) return;

    fetch(
      `https://fundsarthi.onrender.com/api/consultant-slots?consultant_id=${id}&date=${selectedDate}`
    )
      .then(res => res.json())
      .then(data => {

        if (data.status === "success") {

          setSlotTimes(data.data);

        }

      })
      .catch(err => console.error(err));

  }, [selectedDate]);

  const isToday = (date: string) => {
    const today = new Date().toISOString().split("T")[0];
    return date === today;
  };

  const isSlotPassed = (slot: string) => {
    if (!selectedDate || !isToday(selectedDate)) return false;

    const now = new Date();

    const [time, modifier] = slot.split(" ");
    let [hours, minutes] = time.split(":").map(Number);

    if (modifier === "PM" && hours !== 12) {
      hours += 12;
    }

    if (modifier === "AM" && hours === 12) {
      hours = 0;
    }

    const slotDate = new Date();
    slotDate.setHours(hours, minutes, 0, 0);

    return slotDate <= now;
  };

  // ✅ TIME CONVERSION (FIXED)
  const convertTo24Hour = (time: string) => {
    const [hourMin, modifier] = time.split(" ");
    let [hours, minutes] = hourMin.split(":");

    if (modifier === "PM" && hours !== "12") {
      hours = String(parseInt(hours) + 12);
    }

    if (modifier === "AM" && hours === "12") {
      hours = "00";
    }

    return `${hours}:${minutes}:00`;
  };

  // ✅ BOOKING API (FIXED)
  const handleBooking = async () => {
    if (!selectedDate || !selectedSlot) return;

    try {
      const res = await fetch("https://fundsarthi.onrender.com/api/book-consultation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          consultant_id: expert.id,
          consultant_name: expert.full_name,
          user_mobile: localStorage.getItem("userMobile"),

          customer_name: localStorage.getItem("userName") || "User",
          consultation_type: expertiseList[0] || "Residential",

          date: selectedDate, // ✅ correct
          time: selectedSlot, // ✅ FIXED
        }),
      });

      const data = await res.json();

      if (data.status === "success") {
        navigate("/vastu/booking-confirmation", {
          state: {
            expert,
            date: selectedDate,
            time: selectedSlot,
            bookingId: data.booking_id,
          },
        });
      }

    } catch (err) {
      console.error(err);
      alert("Booking failed");
    }
  };

  const serviceMap: any = {
    Residential: "Residential Vastu Consultation",
    Commercial: "Commercial Vastu Planning",
    Industrial: "Site Visit & Analysis",
    Other: "Vastu Correction Remedies",
  };

  if (!expert) return <div className="p-6">Loading...</div>;

  return (
    <div className="h-full flex flex-col bg-background">

      {/* Header */}
      <div className="px-6 py-4 bg-card border-b border-border flex items-center">
        <button onClick={() => navigate(-1)}>
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="ml-4">Expert Profile</h1>
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* Expert Info */}
        <div className="px-6 py-6 bg-card border-b border-border">
          <div className="flex gap-4 mb-4">
            <div className="relative">
              <img
                src={expert.photo || "https://via.placeholder.com/400"}
                className="w-24 h-24 rounded-2xl object-cover"
              />
              {expert.status === "approved" && (
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <BadgeCheck className="w-5 h-5 text-white" />
                </div>
              )}
            </div>

            <div className="flex-1">
              <h2 className="mb-1">{expert.full_name}</h2>
              <p className="text-sm text-muted-foreground mb-2">
                {expertiseList.length > 0 ? expertiseList.join(" • ") : "Vastu Consultant"}
              </p>

              <div className="flex items-center gap-3 text-sm">
                <Star className="w-4 h-4 fill-accent text-accent" />
                <span>4.5 (0)</span>

                <Award className="w-4 h-4 text-primary" />
                <span>{expert.experience} years</span>
              </div>

              <div className="mt-3 inline-flex items-center px-3 py-2 rounded-xl bg-primary/10 text-primary font-semibold text-sm">
                Consultation Fee: ₹{expert.consultation_fee || 500}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-start gap-2 text-muted-foreground col-span-2">
              <MapPin className="w-4 h-4 mt-0.5 shrink-0" />

              <div className="flex flex-col">
                <span className="font-medium text-foreground">
                  {expert.city}
                </span>

                <span className="text-xs leading-relaxed">
                  {expert.address || "Address not available"}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-muted-foreground">
              <Languages className="w-4 h-4" />
              <span>{languages.join(", ")}</span>
            </div>
          </div>
        </div>

        {/* Bio */}
        <div className="px-6 py-6 border-b border-border">
          <h3 className="mb-3">About</h3>
          <p className="text-sm text-muted-foreground leading-relaxed"> {expert.bio || "No description available"} </p>
        </div>

        {/* Services */}
        <div className="px-6 py-6 border-b border-border">
          <h3 className="mb-3">Services Offered</h3>
          <div className="space-y-2">
            {expertiseList.map((service: string, i: number) => (
              <div key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                {serviceMap[service] || service}
              </div>
            ))}
          </div>
        </div>

        {/* Slots */}
        <div className="px-6 py-6">
          <h3 className="mb-4">Available Time Slots</h3>

          {/* Dates */}
          <div className="flex gap-3 overflow-x-auto pb-4 mb-6">
            {dates.map((d, i) => {
              const value = d.value; // ✅ FIX

              return (
                <button
                  key={i}
                  onClick={() => setSelectedDate(value)}
                  className={`flex flex-col items-center min-w-[70px] px-4 py-3 rounded-xl border ${selectedDate === value
                    ? "bg-primary text-white border-primary"
                    : "bg-card border-border"
                    }`}
                >
                  <div className="text-xs">{d.display.day}</div>
                  <div className="text-xl">{d.display.date}</div>
                  <div className="text-xs">{d.display.month}</div>
                </button>
              );
            })}
          </div>

          {/* Time */}
          {selectedDate && (
            <div className="grid grid-cols-3 gap-2">

              {slotTimes.map((slot: any) => {

                const disabled =
                  isSlotPassed(slot.time);

                return (

                  <button
                    key={slot.id}
                    onClick={() =>
                      !disabled &&
                      setSelectedSlot(slot.value)
                    }
                    disabled={disabled}
                    className={`py-3 rounded-xl text-sm transition-all duration-200

          ${disabled
                        ? "bg-gray-100 text-gray-400 cursor-not-allowed border border-gray-200"
                        : selectedSlot === slot.value
                          ? "bg-primary text-white border border-primary shadow-sm"
                          : "bg-card border border-border hover:border-primary hover:text-primary"
                      }`}
                  >

                    {slot.time}

                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 py-4 border-t border-border bg-card">
        <GradientButton
          onClick={handleBooking}
          disabled={!selectedDate || !selectedSlot}
          className="w-full"
        >
          Book Consultation
        </GradientButton>
      </div>
    </div>
  );
}