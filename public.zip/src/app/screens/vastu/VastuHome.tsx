import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { BottomNav } from "../../components/BottomNav";
import { Search, SlidersHorizontal, MapPin, Star, BadgeCheck, Languages, Briefcase } from "lucide-react";

export default function VastuHome() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [experts, setExperts] = useState<any[]>([]);

  // ✅ FETCH FROM BACKEND
  useEffect(() => {
    fetch("https://fundsarthi.onrender.com/api/consultants")
      .then(res => res.json())
      .then(data => {
        if (data.status === "success") {
          setExperts(data.data);
        }
      })
      .catch(err => console.error("API Error:", err));
  }, []);


  // ✅ SEARCH FILTER
  const filteredExperts = experts.filter((expert) =>
    expert.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    expert.location?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="px-6 py-4 bg-card border-b border-border">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h1 className="mb-1">Vastu Experts</h1>
            <p className="text-sm text-muted-foreground">
              Find Trusted Vastu Experts Near You
            </p>
          </div>

          <button
            onClick={() => navigate("/vastu/apply-consultant")}
            className="flex items-center gap-1 px-3 py-1.5 text-xs rounded-full bg-primary text-white shadow-[0_0_12px_rgba(59,130,246,0.6)] hover:shadow-[0_0_18px_rgba(59,130,246,0.9)] transition-all"
          >
            <Briefcase className="w-4 h-4" />
            Become
          </button>
        </div>

        {/* Search Bar */}
        <div className="flex gap-2 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by name or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-11 pl-10 pr-4 rounded-xl border border-border bg-background"
            />
          </div>
          <button className="w-11 h-11 bg-primary rounded-xl flex items-center justify-center text-white">
            <SlidersHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Become Consultant Button */}


        {/* Filter Chips (UI only for now) */}
        {/* <div className="flex gap-2 overflow-x-auto pb-2">
          {["All", "Residential", "Commercial", "Industrial", "Top Rated"].map((chip) => (
            <button
              key={chip}
              className={`px-4 py-2 rounded-full text-sm whitespace-nowrap ${chip === "All"
                  ? "bg-primary text-white"
                  : "bg-card border border-border hover:border-primary"
                }`}
            >
              {chip}
            </button>
          ))}
        </div> */}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20 px-6 py-4">
        <div className="space-y-4">

          {/* ✅ EMPTY STATE */}
          {filteredExperts.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground">
              No experts found 😕
            </div>
          ) : (

            filteredExperts.map((expert) => (
              <button
                key={expert.id}
                onClick={() => navigate(`/vastu/expert/${expert.id}`)}
                className="w-full bg-card rounded-2xl p-5 border border-border hover:shadow-lg transition-shadow"
              >
                <div className="flex gap-4">
                  <div className="relative">
                    <img
                      src={expert.image || "https://via.placeholder.com/200"}
                      alt={expert.name}
                      className="w-20 h-20 rounded-xl object-cover"
                    />
                    {expert.verified && (
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                        <BadgeCheck className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 text-left">
                    <h3 className="mb-1">{expert.name}</h3>

                    <p className="text-sm text-muted-foreground mb-2">
                      {expert.specialization || "Vastu Consultant"}
                    </p>

                    <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                      <span>{expert.experience} exp.</span>

                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-accent text-accent" />
                        <span>
                          {expert.rating || 4.5} ({expert.reviews || 0})
                        </span>
                      </div>
                    </div>

                    <p className="text-primary font-semibold text-sm mt-1">
                      ₹{expert.consultation_fee || 500} Consultation Fee
                    </p>

                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                      <Languages className="w-3 h-3" />
                      <span>
                        {(expert.languages || []).join(", ")}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="w-3 h-3" />
                      <span>{expert.location}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-border">
                  <div className="text-primary text-sm">
                    View Profile & Book Consultation
                  </div>
                </div>
              </button>
            ))

          )}

        </div>
      </div>

      <BottomNav />
    </div>
  );
}